// Package playlist is the playlist page (/playlist/<id>).
package playlist

import (
	"html"
	"image"
	"image/color"
	"regexp"
	"slices"

	"gioui.org/layout"

	"github.com/GGGeorgiev20/personal-spotify/internal/backend"
	"github.com/GGGeorgiev20/personal-spotify/internal/spotify"
	"github.com/GGGeorgiev20/personal-spotify/internal/ui"
)

const pageSize = 100

func init() {
	ui.Register("playlist", func(args []string) ui.Page {
		p := &page{uri: "spotify:playlist:" + args[0], color: ui.RGB(0x535353)}
		p.ctl = ui.ListControls{Hint: "Search in playlist", Default: ui.SortCustom, Options: []ui.SortOpt{
			{Key: ui.SortCustom, Label: "Custom order"}, {Key: ui.SortTitle, Label: "Title"}, {Key: ui.SortArtist, Label: "Artist"},
			{Key: ui.SortAlbum, Label: "Album"}, {Key: ui.SortAdded, Label: "Date added"}, {Key: ui.SortDuration, Label: "Duration"},
		}}
		p.version = ui.PlaylistVersion[p.uri]
		p.load()
		return p
	})
}

type page struct {
	uri     string
	res     ui.Res[*spotify.Playlist]
	cur     *spotify.Playlist // the playlist setup last ran for
	version int
	color   color.NRGBA
	tracks  *ui.Paged
	table   ui.TrackTable
	list    ui.List
	header  ui.EntityHeader
	actions ui.ActionBar
	owner   ui.Link
	member  ui.Link
	promo   ui.Link // "About recommendations"
	headerH int

	ctl  ui.ListControls // search and sort
	view ui.TrackView
	recs recs

	desc    string
	length  string // "about 3 hr", cached per tracks.Gen
	lengthG int
}

func (p *page) load() {
	p.res.Load(func() (*spotify.Playlist, error) { return ui.B.Playlist(p.uri, 0, pageSize) })
}

func (p *page) Chrome() ui.Chrome {
	title := ""
	if p.cur != nil {
		title = p.cur.Name
	}
	return ui.Chrome{Title: title, Color: p.color, ContextURI: p.uri, OnPlay: func() { ui.PlayContext(p.uri) }, Threshold: p.headerH, List: &p.list}
}

var tag = regexp.MustCompile(`<[^>]*>`)

// text drops the HTML links Spotify puts in descriptions.
func text(s string) string { return html.UnescapeString(tag.ReplaceAllString(s, "")) }

// setup runs when a playlist (re)loads.
func (p *page) setup(pl *spotify.Playlist) {
	p.cur = pl
	ui.Saved[p.uri] = pl.Following
	p.desc = text(pl.Description)
	p.tracks = ui.NewPaged(func(off, lim int) (*spotify.TrackPage, error) {
		r, err := ui.B.Playlist(p.uri, off, lim)
		if err != nil {
			return nil, err
		}
		return &r.Tracks, nil
	}, pageSize)
	p.tracks.Seed(pl.Tracks)
	p.lengthG = -1
	p.table = ui.TrackTable{Variant: "playlist", ContextURI: p.uri, PlaylistURI: p.uri, CanEdit: pl.CanEdit, NoAdded: true, NoCheck: pl.CanEdit, Sort: &p.ctl}
	for _, t := range pl.Tracks.Items {
		if t.AddedAt != "" {
			p.table.NoAdded = false
			break
		}
	}
	ui.LoadTasteExcluded(p.uri)
	if pl.CanEdit && !p.recs.res.Done {
		p.recs.fetch(p.uri, p.haveURIs())
	}
	if len(pl.Banner) > 0 {
		p.color = ui.RGB(0x535353) // the official wash under a banner is plain gray
	} else {
		ui.ExtractedColor(pl.Color, pl.Images, func(c color.NRGBA) { p.color = c })
	}
}

// move applies a drag-reorder at once, then syncs with the server (the
// reload also undoes the move if it failed).
func (p *page) move(from, to int, after bool) {
	items := p.tracks.Items
	if to >= len(items) {
		return
	}
	src, dst := items[from], items[to]
	if src == nil || dst == nil || src.UID == "" || dst.UID == "" {
		return
	}
	at := to
	if after {
		at++
	}
	if from < at {
		at--
	}
	p.tracks.Items = slices.Insert(slices.Delete(items, from, from+1), at, src)
	p.table.Selected = at
	pos := spotify.Position{Before: dst.UID}
	if after {
		pos = spotify.Position{After: dst.UID}
	}
	uid := src.UID
	ui.Async(func() (struct{}, error) { return struct{}{}, ui.B.MovePlaylistItems(p.uri, []string{uid}, pos) }, func(_ struct{}, err error) {
		if err != nil {
			ui.Toast("Couldn't move: " + err.Error())
		}
		ui.PlaylistVersion[p.uri]++
	})
}

const (
	itemHeader = iota
	itemActions
	itemTableHeader
	itemRows
)

func (p *page) Layout(gtx layout.Context) layout.Dimensions {
	if v := ui.PlaylistVersion[p.uri]; v != p.version {
		p.version = v
		p.load()
	}
	switch {
	case !p.res.Done:
		return ui.Loading(gtx)
	case p.res.Err != nil:
		return ui.Unavailable(gtx, "This playlist", p.res.Err)
	}
	pl := p.res.V
	if pl != p.cur {
		p.setup(pl)
	}
	if p.owner.Click.Clicked(gtx) {
		ui.OpenURI(pl.Owner.URI)
	}
	if p.member.Click.Clicked(gtx) && len(pl.Members) == 1 {
		ui.OpenURI(pl.Members[0].URI)
	}
	ui.HeaderFade(gtx, p.color, p.headerH-p.list.ScrollTop())
	if !p.list.Scrolled(0) {
		ui.HeaderFade(gtx, p.color, p.headerH)
	}
	p.list.Sticky = func(gtx layout.Context) layout.Dimensions { return p.table.Header(gtx, true) }
	p.list.StickyIndex, p.list.StickyTop = itemTableHeader, ui.Dp(gtx, 64)

	reordered := p.view.Update(p.tracks, &p.ctl, &p.table)
	p.table.OnMove = nil
	if pl.CanEdit && !reordered { // dragging only makes sense in the playlist's own order
		p.table.OnMove = p.move
	}
	n := p.view.Len(p.tracks)
	suggest := pl.CanEdit && p.ctl.Query() == "" // no suggestions under a search
	recs := suggest && p.recs.res.Done && len(p.recs.shown()) > 0
	extra := 0
	if suggest {
		extra = 1
		if recs {
			extra = 2
		}
	}
	d := p.list.Layout(gtx, itemRows+n+extra+1, func(gtx layout.Context, i int) layout.Dimensions {
		switch {
		case i == itemHeader:
			o := ui.HeaderOpts{
				Images: pl.Images, Type: visibility(pl), Title: pl.Name, Color: p.color, Icon: "note",
				Description: p.desc, Banner: pl.Banner,
				Meta: func(gtx layout.Context) layout.Dimensions { return p.meta(gtx, pl) },
			}
			if pl.IsOwner {
				o.OnEdit = func() { ui.EditPlaylist(p.uri, pl.Name, p.desc, nil) }
			}
			d := p.header.Layout(gtx, o)
			p.headerH = d.Size.Y
			return d
		case i == itemActions:
			a := ui.ActionOpts{
				ContextURI: p.uri, Shuffle: true, Download: true,
				Menu: func() []ui.MenuItem {
					return ui.CardMenu(spotify.Card{URI: p.uri, Type: "playlist", Name: pl.Name, Images: pl.Images}, ui.CardMenuOpts{Own: pl.IsOwner, Description: p.desc})
				},
			}
			if !pl.IsOwner {
				a.SaveURI = p.uri
			}
			if pl.CanInvite {
				a.OnInvite, a.InviteLabel = func() { invite(p.uri) }, "Invite collaborators to "+pl.Name
			}
			d := p.actions.Layout(gtx, a)
			if p.tracks.Total > 0 {
				p.ctl.Layout(gtx, d.Size)
			}
			return d
		case i == itemTableHeader:
			return p.table.Header(gtx, false)
		case i < itemRows+n:
			return p.table.Row(gtx, i-itemRows, p.view.At(p.tracks, i-itemRows))
		case n == 0 && reordered && i == itemRows:
			return ui.NoMatches(gtx, p.ctl.Query())
		case suggest && i == itemRows+n:
			return p.layoutFind(gtx, pl)
		case recs && i == itemRows+n+1:
			return p.layoutRecs(gtx, pl)
		}
		return ui.Gap(0, 32)(gtx)
	})
	if !reordered {
		first, last := p.list.Range()
		p.tracks.Ensure(first-itemRows-5, last-itemRows+5)
	}
	return d
}

func (p *page) meta(gtx layout.Context, pl *spotify.Playlist) layout.Dimensions {
	dim := ui.Alpha(ui.ColText, .7)
	var segs []ui.Seg
	if len(pl.Owner.Images) > 0 {
		segs = append(segs, ui.Seg{Widget: func(gtx layout.Context) layout.Dimensions {
			s := ui.Dp(gtx, 24)
			ui.Image{URL: ui.Pick(pl.Owner.Images, s), Round: true}.Layout(gtx, image.Pt(s, s))
			return layout.Dimensions{Size: image.Pt(s+ui.Dp(gtx, 4), s), Baseline: ui.Dp(gtx, 6)}
		}})
	}
	if pl.MadeFor != "" { // generated playlists name the listener, not Spotify
		segs = append(segs, ui.Seg{Text: "Made for ", Color: dim}, ui.Seg{Text: pl.MadeFor, Weight: ui.Bold})
	} else {
		segs = append(segs, ui.Seg{Text: pl.Owner.Name, Link: &p.owner, Weight: ui.Bold})
	}
	switch len(pl.Members) {
	case 0:
	case 1:
		segs = append(segs, ui.Seg{Text: " and ", Color: dim}, ui.Seg{Text: pl.Members[0].Name, Link: &p.member, Weight: ui.Bold})
	default:
		segs = append(segs, ui.Seg{Text: " and " + ui.FmtNumber(len(pl.Members)) + " others", Color: dim})
	}
	if pl.Followers > 0 {
		saves := " saves"
		if pl.Followers == 1 {
			saves = " save"
		}
		segs = append(segs, ui.Seg{Text: " • " + ui.FmtNumber(pl.Followers) + saves, Color: dim})
	}
	if p.lengthG != p.tracks.Gen {
		p.lengthG = p.tracks.Gen
		p.length = ui.FmtListLength(p.tracks.Loaded(), p.tracks.Total)
	}
	songs := " songs"
	if p.tracks.Total == 1 {
		songs = " song"
	}
	s := " • " + ui.FmtNumber(p.tracks.Total) + songs
	if p.length != "" {
		s += ", " + p.length
	}
	segs = append(segs, ui.Seg{Text: s, Color: dim})
	line := func(gtx layout.Context) layout.Dimensions {
		return ui.Inline(gtx, 14, ui.Regular, ui.ColText, ui.ColNone, segs...)
	}
	if !pl.PromoNote {
		return line(gtx)
	}
	if p.promo.Click.Clicked(gtx) {
		backend.OpenURL("https://about-recommendations.spotify.com/")
	}
	return ui.Column(gtx, line, ui.Gap(0, 12), func(gtx layout.Context) layout.Dimensions {
		return p.promo.Layout(gtx, "About recommendations and the impact of promotion", 14, ui.Regular, dim, ui.ColText)
	})
}

// visibility is the header's type line: Spotify shows whether anyone can
// see the playlist.
func visibility(pl *spotify.Playlist) string {
	if pl.Public {
		return "Public Playlist"
	}
	return "Private Playlist"
}

// invite copies a collaborator invite link, as the official button does.
func invite(uri string) {
	ui.Async(func() (string, error) { return ui.B.InviteLink(uri) }, func(link string, err error) {
		if err != nil {
			ui.Toast("Couldn't create an invite link: " + err.Error())
			return
		}
		ui.CopyText(link)
		ui.Toast("Invite link copied to clipboard")
	})
}
